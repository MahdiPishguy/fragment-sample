class Fa {
  static String appName = 'اپلیکیشن کلید جذب';
  static String appDescription = 'رسیدن به خواسته های مادی و معنوی';

  static String registerInApp = 'ثبت نام در اپلیکیشن';
  static String register = 'ثبت نام';
  static String yourMobileNumber = 'شماره موبایل خود را وارد کنید';
  static String pleaseEnterYourMobileNumber = 'برای ثبت نام شماره موبایل فعال خود را وارد کنید';
  static String pleaseEnterSmsCode = 'کد فعال سازی';
  static String yourSmsCode = 'کد ارسال شده به همراه خود را وارد کنید';

  static String activeAccount='فعال سازی حساب کاربری';
}
