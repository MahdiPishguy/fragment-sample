library keidejazb_globals;
var preferences;
