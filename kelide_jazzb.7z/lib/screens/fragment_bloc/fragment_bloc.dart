import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:kelide_jazzb/screens/fragment_bloc/fragment_manager.dart';
import './bloc.dart';

class FragmentBloc extends Bloc<FragmentEvent, FragmentState> {
  @override
  FragmentState get initialState => FragmentInitialState();

  @override
  Stream<FragmentState> mapEventToState(
    FragmentEvent event,
  ) async* {
    if (event is FragmentNavigateEvent) {
      int currentIndex = FragmentManager().navigateToName(event.routeName);
      yield FragmentCurrentState(currentIndex);
    } else if (event is FragmentBackEvent) {
      int currentIndex = FragmentManager().navigateBack();
      if (currentIndex < 0) {
        yield FragmentNoBackState();
      } else {
        yield FragmentBackState(currentIndex);
      }
    }
  }
}
