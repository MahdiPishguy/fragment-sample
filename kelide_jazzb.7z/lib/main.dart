import 'package:flutter/material.dart';
import 'package:kelide_jazzb/backend/localization/fa.dart';
import 'package:kelide_jazzb/database/app_database.dart';
import 'package:kelide_jazzb/database/models.dart';
import 'package:kelide_jazzb/navigation.dart';
import 'package:kelide_jazzb/screens/pages/home/view/home.dart';
import 'package:kelide_jazzb/screens/pages/login/view/login.dart';

void main() async {
  AppDatabase().createModel();

  AppDatabase().initializeDB((result) {
    if (result == true)
    {
      runApp(MyApp());
    }

    return null;
  });

}

class MyApp extends StatelessWidget {
  MyApp() {
    Navigation.initRoutes();
  }
  @override
  Widget build(BuildContext context) {
    //Lesson xcccc = Lesson();
    //Lesson().select().toList();
    //print(xcccc);

    return MaterialApp(
      title: Fa.appName,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Directionality(textDirection: TextDirection.rtl, child: Home()),
    );
  }
}
